<?php echo e($slot); ?>

<?php /**PATH C:\Users\ACER\OneDrive\Desktop\UFEST\Oprec-Ufest-FrontEND\Oprecweb-Backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>