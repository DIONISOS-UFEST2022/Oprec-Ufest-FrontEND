<?php echo e($slot); ?>

<?php /**PATH C:\Users\ACER\OneDrive\Desktop\UFEST\Oprec-Ufest-FrontEND\Oprecweb-Backend\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>