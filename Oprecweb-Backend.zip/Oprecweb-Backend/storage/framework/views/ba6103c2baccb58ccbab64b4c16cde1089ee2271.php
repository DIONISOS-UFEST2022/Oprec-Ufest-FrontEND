<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\ACER\OneDrive\Desktop\UFEST\Oprec-Ufest-FrontEND\Oprecweb-Backend\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>