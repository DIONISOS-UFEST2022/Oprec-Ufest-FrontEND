<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class mahasiswa extends Controller
{
    //
}
